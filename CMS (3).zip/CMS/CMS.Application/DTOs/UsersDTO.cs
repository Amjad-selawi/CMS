﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CMS.Application.DTOs
{
    public class UsersDTO
    {//Updated class
        public string Id { set; get; }
        public string Name { set; get; }
        public string Email { set; get; }
    }
}
