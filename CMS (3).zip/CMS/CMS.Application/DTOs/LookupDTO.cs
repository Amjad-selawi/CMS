﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace CMS.Application.DTOs
{
    public class LookupDTO
    {//Updated class
        public int Id { get; set; }
   
        public string Name { get; set; }
    }
}
