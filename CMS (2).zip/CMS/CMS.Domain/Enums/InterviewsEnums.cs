﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CMS.Domain.Enums
{
    public class InterviewsEnums
    {

    }

    public enum InterviewStatus
    {
        Accepted,
        Rejected,
        Pending,
    }

}
