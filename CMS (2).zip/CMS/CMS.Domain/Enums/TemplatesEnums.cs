﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CMS.Domain.Enums
{
    public class TemplatesEnums
    {
    }

    public enum TemplatesName
    {
        CareerOffer,
        FirstInterview,
        SecondInterview,
        InterviewApprovalCandidate
    }
}
